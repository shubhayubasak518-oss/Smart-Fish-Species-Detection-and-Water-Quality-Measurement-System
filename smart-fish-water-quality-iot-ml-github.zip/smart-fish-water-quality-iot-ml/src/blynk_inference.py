"""One-shot prototype: read Blynk values, predict, and publish a category.

Configure .env from .env.example. Confirm API behavior and datastream types
against your own Blynk template before use.
"""
import os
from pathlib import Path
import joblib
import pandas as pd
import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")
BASE_URL = os.getenv("BLYNK_BASE_URL", "https://blynk.cloud").rstrip("/")
TOKEN = os.getenv("BLYNK_AUTH_TOKEN")
MODEL_PATH = ROOT / "models" / "fish_species_model.joblib"
TIMEOUT = 15
INPUT_PINS = {
    "pH": os.getenv("BLYNK_PH_PIN", "V0"),
    "temperature_c": os.getenv("BLYNK_TEMPERATURE_PIN", "V1"),
    "turbidity": os.getenv("BLYNK_TURBIDITY_PIN", "V2"),
    "tds_ppm": os.getenv("BLYNK_TDS_PIN", "V3"),
}
OUTPUT_PIN = os.getenv("BLYNK_PREDICTION_PIN", "V6")

def read_value(pin):
    response = requests.get(
        f"{BASE_URL}/external/api/get",
        params={"token": TOKEN, pin: ""},
        timeout=TIMEOUT,
    )
    response.raise_for_status()
    value = response.json()
    if isinstance(value, list):
        if not value:
            raise ValueError(f"No value returned for {pin}")
        value = value[0]
    return float(value)

def publish_prediction(pin, prediction):
    response = requests.get(
        f"{BASE_URL}/external/api/update",
        params={"token": TOKEN, pin: prediction},
        timeout=TIMEOUT,
    )
    response.raise_for_status()

def main():
    if not TOKEN:
        raise RuntimeError("Set BLYNK_AUTH_TOKEN in your local .env file.")
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Run `python src/train_model.py` before inference.")
    saved = joblib.load(MODEL_PATH)
    readings = {feature: read_value(pin) for feature, pin in INPUT_PINS.items()}
    row = pd.DataFrame([[readings[name] for name in saved["features"]]],
                       columns=saved["features"])
    prediction = str(saved["model"].predict(row)[0])
    publish_prediction(OUTPUT_PIN, prediction)
    print("Readings:", readings)
    print("Predicted category:", prediction)
    print("Published to:", OUTPUT_PIN)

if __name__ == "__main__":
    main()
