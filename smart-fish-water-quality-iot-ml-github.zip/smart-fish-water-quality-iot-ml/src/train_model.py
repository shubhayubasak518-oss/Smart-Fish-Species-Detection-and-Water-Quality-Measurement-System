"""Train a Random Forest on labelled water-quality data.

The bundled CSV is synthetic demonstration data, not validated aquaculture data.
"""
from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "sample_fish_water_quality.csv"
FEATURES = ["pH", "temperature_c", "turbidity", "tds_ppm"]
TARGET = "fish_species"

def main():
    df = pd.read_csv(DATA_PATH)
    required = FEATURES + [TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing dataset columns: {missing}")
    df = df.dropna(subset=[TARGET])
    X = df[FEATURES].apply(pd.to_numeric, errors="coerce")
    y = df[TARGET].astype(str)
    if y.nunique() < 2:
        raise ValueError("At least two target classes are required.")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("classifier", RandomForestClassifier(
            n_estimators=200, random_state=42, class_weight="balanced"
        )),
    ])
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    model_dir = ROOT / "models"
    report_dir = ROOT / "reports"
    model_dir.mkdir(exist_ok=True)
    report_dir.mkdir(exist_ok=True)
    joblib.dump({"model": model, "features": FEATURES},
                model_dir / "fish_species_model.joblib")
    report = {
        "rows": int(len(df)),
        "features": FEATURES,
        "target": TARGET,
        "accuracy_demo_only": float(accuracy_score(y_test, y_pred)),
        "classification_report": classification_report(
            y_test, y_pred, output_dict=True, zero_division=0
        ),
        "confusion_matrix_labels": sorted(y.unique().tolist()),
        "confusion_matrix": confusion_matrix(
            y_test, y_pred, labels=sorted(y.unique().tolist())
        ).tolist(),
        "warning": "Synthetic data only; metrics are not evidence of real-world performance."
    }
    (report_dir / "evaluation.json").write_text(json.dumps(report, indent=2))
    print(f"Saved model to {model_dir / 'fish_species_model.joblib'}")
    print(f"Demo accuracy (synthetic data only): {report['accuracy_demo_only']:.3f}")
    print("Do not interpret demo metrics as real-world performance.")

if __name__ == "__main__":
    main()
