# Smart Fish Species Detection & Water Quality Monitoring System

An ESP32 + IoT + ML prototype for monitoring selected aquaculture water parameters and predicting a fish-species category from the measurements.

> **Important:** This is a starter repository. Replace example pins, Blynk datastreams, calibration formulas, and the demo dataset with your actual implementation. The included CSV is synthetic demonstration data, not measured farm data. Do not claim its metrics as real-world performance.

## Features
- ESP32 sensor acquisition for pH, water temperature, turbidity, and TDS.
- Wi-Fi telemetry to Blynk IoT Cloud.
- Random Forest training workflow using Python and scikit-learn.
- Example Python client to fetch Blynk readings, run inference, and publish a prediction.
- Calibration and validation checklist.

## Architecture
```text
pH / Temperature / Turbidity / TDS sensors
                  ↓
       ESP32 firmware (C/C++)
                  ↓ Wi-Fi
             Blynk Cloud
                  ↓ HTTPS API
       Python inference client
                  ↓
       Random Forest classifier
                  ↓
       Prediction → Blynk dashboard
```
The classifier runs in Python, not inside Blynk. A Google Colab notebook must remain active while being used as the client. For always-on service, deploy the client on a persistent computer/server or use an appropriate edge deployment.

## Repository structure
```text
firmware/esp32_water_monitor.ino
data/sample_fish_water_quality.csv
data/README.md
src/train_model.py
src/blynk_inference.py
docs/architecture.md
.env.example
.gitignore
requirements.txt
LICENSE
```

## Hardware
- ESP32 development board
- pH sensor and compatible interface
- DS18B20 waterproof temperature sensor
- Turbidity sensor/module
- TDS sensor/module

Verify that sensor outputs are safe for ESP32 inputs. Sensor modules differ; the example pins and conversion formulas in the firmware are placeholders, not universal calibration equations.

## Example Blynk datastreams
| Parameter | Example virtual pin |
|---|---|
| pH | V0 |
| Temperature (°C) | V1 |
| Turbidity reading | V2 |
| TDS reading | V3 |
| Predicted category | V6 |

Create matching datastreams in Blynk and update the pins in firmware and `.env` if needed. Confirm the required output data type for the prediction widget.

## Run the ML demo
```bash
pip install -r requirements.txt
python src/train_model.py
```
The model and evaluation report are written to `models/` and `reports/`. These generated folders are ignored by Git. The bundled data is synthetic and only makes the workflow runnable. Use documented, labelled, representative data for meaningful evaluation.

## Run the Blynk inference example
1. Copy `.env.example` to `.env`.
2. Add your private Blynk device token and verify your virtual pins.
3. Train the model using the command above.
4. Run `python src/blynk_inference.py`.

This is a one-shot prototype. Verify the current Blynk API response format and test the complete flow with your own template. Never commit `.env` or publish your auth token.

## Validation checklist
- [ ] Calibrate pH using suitable buffer solutions.
- [ ] Compare DS18B20 readings with a trusted thermometer.
- [ ] Calibrate turbidity and TDS according to the sensor manufacturer.
- [ ] Record sensor models, units, calibration dates, and conditions.
- [ ] Check dataset provenance, class balance, and label quality.
- [ ] Evaluate with independent samples and report per-class metrics.
- [ ] Test the full sensor → Blynk → Python → prediction flow.

## Limitations
- Water parameters alone may not uniquely identify fish species; predictions reflect the training labels and are not proof that a species is suitable for a pond.
- Synthetic demo data cannot support scientific or real-world accuracy claims.
- Sensor calibration and drift affect measurement quality.
- Do not claim ammonia or dissolved-oxygen measurement unless suitable sensors were actually integrated and validated.

## Resume bullet (edit to reflect completed work)
Built an ESP32-based IoT water-quality monitoring prototype using pH, temperature, turbidity, and TDS sensors; streamed readings to Blynk Cloud and developed a Python/scikit-learn Random Forest workflow for fish-species category prediction.

Only claim the Blynk-to-Python-to-dashboard integration if you have tested it end-to-end.
