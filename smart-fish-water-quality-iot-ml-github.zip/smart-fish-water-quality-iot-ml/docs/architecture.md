# Architecture and data flow

1. Sensors measure pH, temperature, turbidity, and TDS.
2. ESP32 reads sensor signals, applies calibrated conversions, and sends values to Blynk over Wi-Fi.
3. A Python client fetches the latest values through the Blynk HTTPS API.
4. The client arranges readings in the feature order used during model training.
5. The saved scikit-learn pipeline predicts a fish-species category.
6. The client publishes the category to a Blynk output datastream.

## Engineering considerations
- Calibrate each sensor using manufacturer-recommended methods and reference standards.
- Keep units and feature order consistent across firmware, Blynk, and training data.
- Handle missing, stale, disconnected, or out-of-range readings before inference.
- Validate with independent, representative samples and report per-class metrics.
- A notebook is not a persistent backend; use a persistent host for continuous operation.
