/*
 * ESP32 water monitor - reference firmware.
 * Example pins/formulas only: update and calibrate for your exact modules.
 * Never commit real Wi-Fi credentials or a private Blynk token.
 *
 * Example virtual pins: V0=pH, V1=temperature, V2=turbidity, V3=TDS.
 */
#define BLYNK_TEMPLATE_ID   "YOUR_TEMPLATE_ID"
#define BLYNK_TEMPLATE_NAME "Fish Water Quality Monitor"
#define BLYNK_AUTH_TOKEN    "YOUR_DEVICE_AUTH_TOKEN"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <OneWire.h>
#include <DallasTemperature.h>

char ssid[] = "YOUR_WIFI_SSID";
char pass[] = "YOUR_WIFI_PASSWORD";

constexpr int PH_PIN = 34;
constexpr int TURBIDITY_PIN = 32;
constexpr int TDS_PIN = 35;
constexpr int ONE_WIRE_BUS = 4;
constexpr float ADC_REFERENCE_V = 3.3f;
constexpr int ADC_MAX_VALUE = 4095;

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature temperatureSensor(&oneWire);
BlynkTimer timer;

float readVoltage(int pin) {
  return (static_cast<float>(analogRead(pin)) / ADC_MAX_VALUE) * ADC_REFERENCE_V;
}

// PLACEHOLDER: replace with the slope/intercept from your own pH calibration.
float readPHPlaceholder() {
  return 7.0f + (2.5f - readVoltage(PH_PIN)) * 3.5f;
}

// These return voltage, not calibrated NTU or ppm.
float readTurbidityVoltage() { return readVoltage(TURBIDITY_PIN); }
float readTDSVoltage() { return readVoltage(TDS_PIN); }

void publishReadings() {
  temperatureSensor.requestTemperatures();
  float temperatureC = temperatureSensor.getTempCByIndex(0);
  float pH = readPHPlaceholder();
  float turbidityVoltage = readTurbidityVoltage();
  float tdsVoltage = readTDSVoltage();

  Blynk.virtualWrite(V0, pH);
  Blynk.virtualWrite(V1, temperatureC);
  Blynk.virtualWrite(V2, turbidityVoltage); // Calibrate before calling this NTU.
  Blynk.virtualWrite(V3, tdsVoltage);       // Calibrate before calling this ppm.

  Serial.printf("pH=%.2f, temp=%.2f C, turbidity=%.3f V, TDS=%.3f V\n",
                pH, temperatureC, turbidityVoltage, tdsVoltage);
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  temperatureSensor.begin();
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
  timer.setInterval(5000L, publishReadings);
}

void loop() {
  Blynk.run();
  timer.run();
}
